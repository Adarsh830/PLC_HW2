package com.arithmetic.lang.AST;

public class EmptyNode extends StmtNode {
    @Override
    public String toString() {
        return ";";
    }
}
