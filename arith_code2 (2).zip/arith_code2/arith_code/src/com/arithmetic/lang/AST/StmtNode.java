package com.arithmetic.lang.AST;

public abstract class StmtNode {}
